import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/auth_controller.dart';
import '../products/products_screen.dart';
import '../employees/employees_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authController = Get.find<AuthController>();

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),

      // App Bar
      appBar: AppBar(
        title: const Text(
          'Employee Management',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,
        elevation: 0,

        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () async {
              await authController.logout();
            },
          ),
        ],
      ),

      // Dashboard Body
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Section
            const Text(
              'Welcome Back!',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B),
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'Manage your products and employees.',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),

            const SizedBox(height: 30),

            // Dashboard Title
            const Text(
              'Dashboard',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B),
              ),
            ),

            const SizedBox(height: 16),

            // Products Card
            dashboardCard(
              icon: Icons.inventory_2,
              title: 'Products',
              subtitle: 'View Network Technology products',
              onTap: () {
                Get.to(() => const ProductsScreen());
              },
            ),

            const SizedBox(height: 16),

            // Employees Card
            dashboardCard(
              icon: Icons.people,
              title: 'Employees',
              subtitle: 'Manage employee records',
              onTap: () {
                Get.to(() => const EmployeesScreen());
              },
            ),

            const SizedBox(height: 25),

            // Information Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),

              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(14),
              ),

              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: Color(0xFF2563EB), size: 28),

                  SizedBox(width: 12),

                  Expanded(
                    child: Text(
                      'Use this dashboard to access products and employee management features.',
                      style: TextStyle(
                        color: Color(0xFF1E40AF),
                        fontSize: 13,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Reusable Dashboard Card
  Widget dashboardCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      color: Colors.white,
      elevation: 2,
      margin: EdgeInsets.zero,

      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),

      child: ListTile(
        contentPadding: const EdgeInsets.all(18),

        leading: Container(
          width: 52,
          height: 52,

          decoration: BoxDecoration(
            color: const Color(0xFFEFF6FF),
            borderRadius: BorderRadius.circular(12),
          ),

          child: Icon(icon, size: 28, color: const Color(0xFF2563EB)),
        ),

        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 17,
            color: Color(0xFF1E293B),
          ),
        ),

        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(
            subtitle,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ),

        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 17,
          color: Colors.grey,
        ),

        onTap: onTap,
      ),
    );
  }
}

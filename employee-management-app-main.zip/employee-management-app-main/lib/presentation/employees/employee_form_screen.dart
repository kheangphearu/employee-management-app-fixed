import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../controllers/employee_controller.dart';
import '../../data/models/employee_model.dart';

class EmployeeFormScreen extends StatefulWidget {
  final Employee? employee;
  const EmployeeFormScreen({super.key, this.employee});
  @override
  State<EmployeeFormScreen> createState() => _EmployeeFormScreenState();
}

class _EmployeeFormScreenState extends State<EmployeeFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final EmployeeController controller = Get.find<EmployeeController>();
  final ImagePicker _picker = ImagePicker();
  late final TextEditingController firstNameController;
  late final TextEditingController lastNameController;
  late final TextEditingController emailController;
  late final TextEditingController phoneController;
  late final TextEditingController departmentController;
  Uint8List? _imageBytes;
  String _imageData = '';
  bool _pickingImage = false;
  bool get isEditing => widget.employee != null;

  @override
  void initState() {
    super.initState();
    firstNameController = TextEditingController(
      text: widget.employee?.firstName ?? '',
    );
    lastNameController = TextEditingController(
      text: widget.employee?.lastName ?? '',
    );
    emailController = TextEditingController(text: widget.employee?.email ?? '');
    phoneController = TextEditingController(text: widget.employee?.phone ?? '');
    departmentController = TextEditingController(
      text: widget.employee?.department ?? '',
    );
    final existing = widget.employee?.image ?? '';
    if (existing.startsWith('data:image') && existing.contains(',')) {
      try {
        _imageData = existing;
        _imageBytes = base64Decode(
          existing.substring(existing.indexOf(',') + 1),
        );
      } catch (_) {}
    }
  }

  @override
  void dispose() {
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    departmentController.dispose();
    super.dispose();
  }

  Future<void> _chooseImage() async {
    try {
      setState(() => _pickingImage = true);
      final XFile? file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 78,
        maxWidth: 1200,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      final mime =
          file.mimeType ??
          (file.name.toLowerCase().endsWith('.png')
              ? 'image/png'
              : 'image/jpeg');
      setState(() {
        _imageBytes = bytes;
        _imageData = 'data:$mime;base64,${base64Encode(bytes)}';
      });
    } catch (e) {
      Get.snackbar(
        'Image selection failed',
        'Unable to select this image. Please try another file.',
      );
    } finally {
      if (mounted) setState(() => _pickingImage = false);
    }
  }

  Future<void> submitForm() async {
    if (!_formKey.currentState!.validate()) return;
    final employee = Employee(
      id: widget.employee?.id ?? 0,
      firstName: firstNameController.text.trim(),
      lastName: lastNameController.text.trim(),
      email: emailController.text.trim(),
      phone: phoneController.text.trim(),
      image: _imageData.isNotEmpty
          ? _imageData
          : (widget.employee?.image ?? ''),
      department: departmentController.text.trim(),
    );
    final success = isEditing
        ? await controller.updateEmployee(employee)
        : await controller.addEmployee(employee);
    if (success && mounted) Get.back();
  }

  InputDecoration _decoration(String hint, IconData icon) => InputDecoration(
    hintText: hint,
    prefixIcon: Icon(icon, color: const Color(0xFF2563EB)),
    filled: true,
    fillColor: const Color(0xFFF8FAFC),
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(13),
      borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(13),
      borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(13),
      borderSide: const BorderSide(color: Color(0xFF2563EB), width: 1.5),
    ),
  );

  Widget _field(
    String label,
    TextEditingController textController,
    String hint,
    IconData icon, {
    TextInputType keyboardType = TextInputType.text,
    bool email = false,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 17),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              color: Color(0xFF334155),
            ),
          ),
        ),
        TextFormField(
          controller: textController,
          keyboardType: keyboardType,
          decoration: _decoration(hint, icon),
          validator: (value) {
            if (value == null || value.trim().isEmpty)
              return '$label is required';
            if (email && !GetUtils.isEmail(value.trim()))
              return 'Please enter a valid email address';
            return null;
          },
        ),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: Text(
          isEditing ? 'Edit Employee' : 'Add Employee',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0F172A),
        elevation: 0.5,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Card(
              color: Colors.white,
              elevation: 2,
              shadowColor: const Color(0xFF0F172A).withOpacity(.05),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(22),
              ),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        isEditing
                            ? 'Update employee details'
                            : 'Create a new employee profile',
                        style: const TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF0F172A),
                        ),
                      ),
                      const SizedBox(height: 7),
                      const Text(
                        'Add personal information and an employee profile photo.',
                        style: TextStyle(color: Color(0xFF64748B)),
                      ),
                      const SizedBox(height: 24),
                      Center(
                        child: Column(
                          children: [
                            Stack(
                              children: [
                                Container(
                                  width: 122,
                                  height: 122,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: const Color(0xFFEFF6FF),
                                    border: Border.all(
                                      color: const Color(0xFFBFDBFE),
                                      width: 3,
                                    ),
                                  ),
                                  child: ClipOval(
                                    child: _imageBytes != null
                                        ? Image.memory(
                                            _imageBytes!,
                                            fit: BoxFit.cover,
                                            width: 122,
                                            height: 122,
                                          )
                                        : ((widget.employee?.image ?? '')
                                                  .startsWith('http')
                                              ? Image.network(
                                                  widget.employee!.image,
                                                  fit: BoxFit.cover,
                                                  width: 122,
                                                  height: 122,
                                                  errorBuilder:
                                                      (
                                                        context,
                                                        error,
                                                        stackTrace,
                                                      ) => const Icon(
                                                        Icons.person_rounded,
                                                        size: 65,
                                                        color: Color(
                                                          0xFF2563EB,
                                                        ),
                                                      ),
                                                )
                                              : const Icon(
                                                  Icons.person_rounded,
                                                  size: 65,
                                                  color: Color(0xFF2563EB),
                                                )),
                                  ),
                                ),
                                Positioned(
                                  right: 0,
                                  bottom: 0,
                                  child: Material(
                                    color: const Color(0xFF2563EB),
                                    shape: const CircleBorder(),
                                    child: InkWell(
                                      customBorder: const CircleBorder(),
                                      onTap: _pickingImage
                                          ? null
                                          : _chooseImage,
                                      child: Padding(
                                        padding: const EdgeInsets.all(10),
                                        child: _pickingImage
                                            ? const SizedBox(
                                                width: 18,
                                                height: 18,
                                                child:
                                                    CircularProgressIndicator(
                                                      strokeWidth: 2,
                                                      color: Colors.white,
                                                    ),
                                              )
                                            : const Icon(
                                                Icons.camera_alt_rounded,
                                                color: Colors.white,
                                                size: 19,
                                              ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 11),
                            TextButton.icon(
                              onPressed: _pickingImage ? null : _chooseImage,
                              icon: const Icon(Icons.upload_rounded),
                              label: Text(
                                _imageBytes == null
                                    ? 'Upload Profile Photo'
                                    : 'Change Photo',
                              ),
                            ),
                            const Text(
                              'JPG, PNG or other gallery image',
                              style: TextStyle(
                                fontSize: 11,
                                color: Color(0xFF94A3B8),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      _field(
                        'First Name',
                        firstNameController,
                        'Enter first name',
                        Icons.person_outline_rounded,
                      ),
                      _field(
                        'Last Name',
                        lastNameController,
                        'Enter last name',
                        Icons.person_outline_rounded,
                      ),
                      _field(
                        'Email Address',
                        emailController,
                        'name@example.com',
                        Icons.email_outlined,
                        keyboardType: TextInputType.emailAddress,
                        email: true,
                      ),
                      _field(
                        'Phone Number',
                        phoneController,
                        'Enter phone number',
                        Icons.phone_outlined,
                        keyboardType: TextInputType.phone,
                      ),
                      _field(
                        'Department',
                        departmentController,
                        'e.g. Human Resources',
                        Icons.business_outlined,
                      ),
                      const SizedBox(height: 7),
                      Obx(
                        () => SizedBox(
                          height: 53,
                          child: ElevatedButton.icon(
                            onPressed: controller.isLoading.value
                                ? null
                                : submitForm,
                            icon: controller.isLoading.value
                                ? const SizedBox(
                                    width: 19,
                                    height: 19,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  )
                                : Icon(
                                    isEditing
                                        ? Icons.save_rounded
                                        : Icons.person_add_alt_1_rounded,
                                  ),
                            label: Text(
                              controller.isLoading.value
                                  ? 'Please wait...'
                                  : (isEditing
                                        ? 'Save Changes'
                                        : 'Add Employee'),
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF2563EB),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(13),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton(
                        onPressed: () => Get.back(),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size.fromHeight(48),
                          foregroundColor: const Color(0xFF475569),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(13),
                          ),
                        ),
                        child: const Text('Cancel'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

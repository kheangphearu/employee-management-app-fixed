import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/employee_controller.dart';
import 'employee_form_screen.dart';

class EmployeesScreen extends StatelessWidget {
  const EmployeesScreen({super.key});

  Widget _avatarPlaceholder() => Container(
    width: 65,
    height: 65,
    color: const Color(0xFFEFF6FF),
    child: const Icon(Icons.person, size: 35, color: Color(0xFF2563EB)),
  );

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(EmployeeController());

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),

      // App Bar
      appBar: AppBar(
        title: const Text(
          'Employee Management',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,

        actions: [
          IconButton(
            tooltip: 'Add Employee',
            icon: const Icon(Icons.person_add_alt_1),
            onPressed: () {
              Get.to(() => const EmployeeFormScreen());
            },
          ),
        ],
      ),

      // Employee List
      body: Obx(() {
        // Loading
        if (controller.isLoading.value && controller.employees.isEmpty) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFF2563EB)),
          );
        }

        // Error
        if (controller.errorMessage.value.isNotEmpty &&
            controller.employees.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.cloud_off, size: 60, color: Colors.grey),
                  const SizedBox(height: 15),

                  Text(
                    controller.errorMessage.value,
                    textAlign: TextAlign.center,
                  ),

                  const SizedBox(height: 15),

                  ElevatedButton.icon(
                    onPressed: controller.refreshEmployees,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Retry'),
                  ),
                ],
              ),
            ),
          );
        }

        // Empty
        if (controller.employees.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.people_outline, size: 65, color: Colors.grey),

                const SizedBox(height: 12),

                const Text(
                  'No employees found',
                  style: TextStyle(color: Colors.grey, fontSize: 16),
                ),

                const SizedBox(height: 15),

                ElevatedButton.icon(
                  onPressed: () {
                    Get.to(() => const EmployeeFormScreen());
                  },
                  icon: const Icon(Icons.add),
                  label: const Text('Add Employee'),
                ),
              ],
            ),
          );
        }

        // Employee List
        return RefreshIndicator(
          color: const Color(0xFF2563EB),
          onRefresh: controller.refreshEmployees,

          child: ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: controller.employees.length,

            itemBuilder: (context, index) {
              final employee = controller.employees[index];

              return Card(
                color: Colors.white,
                elevation: 2,
                margin: const EdgeInsets.only(bottom: 14),

                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),

                child: Padding(
                  padding: const EdgeInsets.all(14),

                  child: Row(
                    children: [
                      // Employee Image
                      ClipRRect(
                        borderRadius: BorderRadius.circular(50),

                        child:
                            employee.image.startsWith('data:image') &&
                                employee.image.contains(',')
                            ? Image.memory(
                                base64Decode(
                                  employee.image.substring(
                                    employee.image.indexOf(',') + 1,
                                  ),
                                ),
                                width: 65,
                                height: 65,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    _avatarPlaceholder(),
                              )
                            : Image.network(
                                employee.image,
                                width: 65,
                                height: 65,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    _avatarPlaceholder(),
                              ),
                      ),

                      const SizedBox(width: 14),

                      // Employee Information
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${employee.firstName} ${employee.lastName}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,

                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E293B),
                              ),
                            ),

                            const SizedBox(height: 6),

                            Text(
                              employee.email,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,

                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),

                            const SizedBox(height: 5),

                            Text(
                              employee.phone,
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              ),
                            ),

                            const SizedBox(height: 5),

                            Text(
                              employee.department,
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF2563EB),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(width: 5),

                      // Edit and Delete Buttons
                      Column(
                        children: [
                          IconButton(
                            tooltip: 'Edit Employee',
                            icon: const Icon(
                              Icons.edit_outlined,
                              color: Color(0xFF2563EB),
                            ),

                            onPressed: () {
                              Get.to(
                                () => EmployeeFormScreen(employee: employee),
                              );
                            },
                          ),

                          IconButton(
                            tooltip: 'Delete Employee',
                            icon: const Icon(
                              Icons.delete_outline,
                              color: Colors.red,
                            ),

                            onPressed: () {
                              _confirmDelete(
                                controller,
                                employee.id,
                                '${employee.firstName} ${employee.lastName}',
                              );
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      }),
    );
  }

  // Delete Confirmation Dialog
  void _confirmDelete(
    EmployeeController controller,
    int id,
    String employeeName,
  ) {
    Get.dialog(
      AlertDialog(
        title: const Text('Delete Employee'),

        content: Text('Are you sure you want to delete $employeeName?'),

        actions: [
          TextButton(
            onPressed: () {
              Get.back();
            },
            child: const Text('Cancel'),
          ),

          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),

            onPressed: () async {
              Get.back();
              await controller.deleteEmployee(id);
            },

            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

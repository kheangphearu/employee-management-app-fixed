import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controllers/product_controller.dart';
import '../../data/models/product_model.dart';

class ProductFormScreen extends StatefulWidget {
  final Product? product;

  const ProductFormScreen({super.key, this.product});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();

  final ProductController controller = Get.find<ProductController>();

  late final TextEditingController titleController;
  late final TextEditingController descriptionController;
  late final TextEditingController priceController;
  late final TextEditingController ratingController;
  late final TextEditingController imageController;
  late final TextEditingController categoryController;

  bool get isEditing => widget.product != null;

  @override
  void initState() {
    super.initState();

    final product = widget.product;

    titleController = TextEditingController(text: product?.title ?? '');

    descriptionController = TextEditingController(
      text: product?.description ?? '',
    );

    priceController = TextEditingController(
      text: product?.price.toString() ?? '',
    );

    ratingController = TextEditingController(
      text: product?.rating.toString() ?? '5.0',
    );

    imageController = TextEditingController(text: product?.thumbnail ?? '');

    categoryController = TextEditingController(text: product?.category ?? '');
  }

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    priceController.dispose();
    ratingController.dispose();
    imageController.dispose();
    categoryController.dispose();

    super.dispose();
  }

  // Submit Product Form
  Future<void> submitForm() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final product = Product(
      id: widget.product?.id ?? 0,
      title: titleController.text.trim(),
      description: descriptionController.text.trim(),
      price: double.parse(priceController.text.trim()),
      thumbnail: imageController.text.trim(),
      rating: double.parse(ratingController.text.trim()),
      category: categoryController.text.trim(),
    );

    bool success;

    if (isEditing) {
      success = await controller.updateProduct(product);
    } else {
      success = await controller.addProduct(product);
    }

    if (success && mounted) {
      Get.back();
    }
  }

  // Reusable Text Field
  Widget buildTextField({
    required String label,
    required TextEditingController textController,
    required IconData icon,
    String? hint,
    int maxLines = 1,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            color: Color(0xFF334155),
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: textController,
          maxLines: maxLines,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Icon(icon, color: const Color(0xFF2563EB)),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFE2E8F0)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFF2563EB),
                width: 1.5,
              ),
            ),
          ),
          validator: validator,
        ),
        const SizedBox(height: 18),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: Text(
          isEditing ? 'Edit Product' : 'Add Product',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isEditing
                    ? 'Update Product Information'
                    : 'Enter Product Information',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1E293B),
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                'Please fill in the product details below.',
                style: TextStyle(color: Colors.grey),
              ),

              const SizedBox(height: 25),

              buildTextField(
                label: 'Product Name',
                textController: titleController,
                icon: Icons.inventory_2_outlined,
                hint: 'Enter product name',
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Product name is required';
                  }
                  return null;
                },
              ),

              buildTextField(
                label: 'Description',
                textController: descriptionController,
                icon: Icons.description_outlined,
                hint: 'Enter product description',
                maxLines: 3,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Description is required';
                  }
                  return null;
                },
              ),

              buildTextField(
                label: 'Price (\$)',
                textController: priceController,
                icon: Icons.attach_money,
                hint: 'Enter product price',
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                validator: (value) {
                  final price = double.tryParse(value ?? '');

                  if (price == null || price <= 0) {
                    return 'Enter a valid price greater than 0';
                  }
                  return null;
                },
              ),

              buildTextField(
                label: 'Rating',
                textController: ratingController,
                icon: Icons.star_outline,
                hint: 'Example: 4.5',
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                validator: (value) {
                  final rating = double.tryParse(value ?? '');

                  if (rating == null || rating < 0 || rating > 5) {
                    return 'Rating must be between 0 and 5';
                  }
                  return null;
                },
              ),

              buildTextField(
                label: 'Category',
                textController: categoryController,
                icon: Icons.category_outlined,
                hint: 'Router, Switch, Firewall...',
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Category is required';
                  }
                  return null;
                },
              ),

              buildTextField(
                label: 'Product Image URL',
                textController: imageController,
                icon: Icons.image_outlined,
                hint: 'https://example.com/image.jpg',
                keyboardType: TextInputType.url,
                validator: (value) {
                  final uri = Uri.tryParse(value?.trim() ?? '');

                  if (uri == null ||
                      !uri.hasScheme ||
                      !['http', 'https'].contains(uri.scheme) ||
                      uri.host.isEmpty) {
                    return 'Enter a valid image URL';
                  }
                  return null;
                },
              ),

              // Image Preview
              const Text(
                'Image Preview',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF334155),
                ),
              ),

              const SizedBox(height: 10),

              Container(
                width: double.infinity,
                height: 180,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: ValueListenableBuilder<TextEditingValue>(
                  valueListenable: imageController,
                  builder: (context, value, child) {
                    final url = value.text.trim();

                    if (url.isEmpty) {
                      return const Center(
                        child: Icon(
                          Icons.image_outlined,
                          size: 55,
                          color: Colors.grey,
                        ),
                      );
                    }

                    return ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        url,
                        fit: BoxFit.contain,
                        errorBuilder: (context, error, stackTrace) {
                          return const Center(
                            child: Text(
                              'Unable to load image',
                              style: TextStyle(color: Colors.red),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 25),

              // Submit Button
              Obx(
                () => SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: controller.isLoading.value ? null : submitForm,
                    icon: Icon(isEditing ? Icons.save : Icons.add),
                    label: Text(
                      controller.isLoading.value
                          ? 'Please wait...'
                          : isEditing
                          ? 'Update Product'
                          : 'Add Product',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2563EB),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton(
                  onPressed: () => Get.back(),
                  child: const Text('Cancel'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:dio/dio.dart';

import '../../app/core/constants/api_constants.dart';
import '../models/product_model.dart';

class ProductRepository {
  late final Dio _dio;

  ProductRepository({Dio? dio}) {
    _dio =
        dio ??
        Dio(
          BaseOptions(
            baseUrl: ApiConstants.localApiBaseUrl,
            connectTimeout: const Duration(seconds: 10),
            receiveTimeout: const Duration(seconds: 10),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          ),
        );
  }

  // 1. Get all products
  Future<List<Product>> getProducts() async {
    try {
      final response = await _dio.get(ApiConstants.products);

      final List<dynamic> data = response.data;

      return data.map((json) => Product.fromJson(json)).toList();
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to load products: $e');
    }
  }

  // 2. Add new product
  Future<Product> addProduct(Product product) async {
    try {
      final data = product.toJson();

      // JSON Server will generate ID automatically
      data.remove('id');

      final response = await _dio.post(ApiConstants.products, data: data);

      return Product.fromJson(response.data);
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to add product: $e');
    }
  }

  // 3. Update product
  Future<Product> updateProduct(Product product) async {
    try {
      final response = await _dio.put(
        '${ApiConstants.products}/${product.id}',
        data: product.toJson(),
      );

      return Product.fromJson(response.data);
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to update product: $e');
    }
  }

  // 4. Delete product
  Future<void> deleteProduct(int id) async {
    try {
      await _dio.delete('${ApiConstants.products}/$id');
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to delete product: $e');
    }
  }
}

import 'package:get_storage/get_storage.dart';

import '../../app/core/constants/api_constants.dart';
import '../../app/core/services/api_service.dart';

class AuthRepository {
  final ApiService apiService;
  final GetStorage storage = GetStorage();

  AuthRepository({ApiService? apiService})
    : apiService = apiService ?? ApiService();

  // Login using REST API
  Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) async {
    final response = await apiService.post(
      ApiConstants.login,
      data: {'username': username, 'password': password},
    );

    final data = Map<String, dynamic>.from(response.data);

    // Save JWT tokens
    if (data['accessToken'] != null) {
      await storage.write('accessToken', data['accessToken']);
    }

    if (data['refreshToken'] != null) {
      await storage.write('refreshToken', data['refreshToken']);
    }

    return data;
  }

  // Logout
  Future<void> logout() async {
    await storage.remove('accessToken');
    await storage.remove('refreshToken');
  }
}

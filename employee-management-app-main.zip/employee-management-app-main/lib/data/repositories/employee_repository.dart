import 'package:dio/dio.dart';

import '../../app/core/constants/api_constants.dart';
import '../models/employee_model.dart';

class EmployeeRepository {
  late final Dio _dio;

  EmployeeRepository({Dio? dio}) {
    _dio =
        dio ??
        Dio(
          BaseOptions(
            baseUrl: ApiConstants.employeeBaseUrl,
            connectTimeout: const Duration(seconds: 10),
            receiveTimeout: const Duration(seconds: 10),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          ),
        );
  }

  // 1. Get all employees
  Future<List<Employee>> getEmployees() async {
    try {
      final response = await _dio.get(ApiConstants.employees);

      final List<dynamic> data = response.data;

      return data.map((json) => Employee.fromJson(json)).toList();
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to load employees: $e');
    }
  }

  // 2. Add new employee
  Future<Employee> addEmployee(Employee employee) async {
    try {
      final data = employee.toJson();

      // ឱ្យ JSON Server បង្កើត ID ដោយស្វ័យប្រវត្តិ
      data.remove('id');

      final response = await _dio.post(ApiConstants.employees, data: data);

      return Employee.fromJson(response.data);
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to add employee: $e');
    }
  }

  // 3. Update employee
  Future<Employee> updateEmployee(Employee employee) async {
    try {
      final response = await _dio.put(
        '${ApiConstants.employees}/${employee.id}',
        data: employee.toJson(),
      );

      return Employee.fromJson(response.data);
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to update employee: $e');
    }
  }

  // 4. Delete employee
  Future<void> deleteEmployee(int id) async {
    try {
      await _dio.delete('${ApiConstants.employees}/$id');
    } on DioException {
      rethrow;
    } catch (e) {
      throw Exception('Failed to delete employee: $e');
    }
  }
}

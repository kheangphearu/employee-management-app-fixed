import 'package:dio/dio.dart';
import 'package:get/get.dart';

import '../data/models/product_model.dart';
import '../data/repositories/product_repository.dart';

class ProductController extends GetxController {
  final ProductRepository productRepository;

  ProductController({ProductRepository? productRepository})
    : productRepository = productRepository ?? ProductRepository();

  // Product List
  final RxList<Product> products = <Product>[].obs;

  // Loading State
  final RxBool isLoading = false.obs;

  // Error Message
  final RxString errorMessage = ''.obs;

  // Fetch all products
  Future<void> fetchProducts() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final result = await productRepository.getProducts();

      products.assignAll(result);
    } on DioException catch (e) {
      errorMessage.value = e.response?.data is Map
          ? e.response?.data['message']?.toString() ??
                'Failed to load products.'
          : 'Unable to connect to server.';
    } catch (e) {
      errorMessage.value = 'Something went wrong: $e';
    } finally {
      isLoading.value = false;
    }
  }

  // Add new product
  Future<bool> addProduct(Product product) async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final newProduct = await productRepository.addProduct(product);

      products.add(newProduct);

      Get.snackbar(
        'Success',
        'Product added successfully!',
        snackPosition: SnackPosition.BOTTOM,
      );

      return true;
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to add product: $e',
        snackPosition: SnackPosition.BOTTOM,
      );

      return false;
    } finally {
      isLoading.value = false;
    }
  }

  // Update product
  Future<bool> updateProduct(Product product) async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final updatedProduct = await productRepository.updateProduct(product);

      final index = products.indexWhere((item) => item.id == updatedProduct.id);

      if (index != -1) {
        products[index] = updatedProduct;
      }

      Get.snackbar(
        'Success',
        'Product updated successfully!',
        snackPosition: SnackPosition.BOTTOM,
      );

      return true;
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to update product: $e',
        snackPosition: SnackPosition.BOTTOM,
      );

      return false;
    } finally {
      isLoading.value = false;
    }
  }

  // Delete product
  Future<bool> deleteProduct(int id) async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      await productRepository.deleteProduct(id);

      products.removeWhere((product) => product.id == id);

      Get.snackbar(
        'Success',
        'Product deleted successfully!',
        snackPosition: SnackPosition.BOTTOM,
      );

      return true;
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to delete product: $e',
        snackPosition: SnackPosition.BOTTOM,
      );

      return false;
    } finally {
      isLoading.value = false;
    }
  }

  // Refresh products
  Future<void> refreshProducts() async {
    await fetchProducts();
  }
}

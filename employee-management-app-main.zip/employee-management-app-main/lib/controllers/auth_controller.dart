import 'package:get/get.dart';

import '../data/repositories/auth_repository.dart';
import '../presentation/home/home_screen.dart';
import '../presentation/login/login_screen.dart';

class AuthController extends GetxController {
  final AuthRepository authRepository;
  AuthController({AuthRepository? authRepository})
    : authRepository = authRepository ?? AuthRepository();

  final RxBool isLoading = false.obs;

  // Demo credentials. Replace with server-side authentication before production.
  static const String demoUsername = 'admin';
  static const String demoPassword = 'admin@1234';

  Future<void> login({
    required String username,
    required String password,
  }) async {
    isLoading.value = true;
    try {
      await Future<void>.delayed(const Duration(milliseconds: 450));
      if (username.trim() == demoUsername && password == demoPassword) {
        Get.snackbar(
          'Login Successful',
          'Welcome, Administrator!',
          snackPosition: SnackPosition.BOTTOM,
        );
        Get.offAll(() => const HomeScreen());
      } else {
        Get.snackbar(
          'Login Failed',
          'Incorrect username or password.',
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> logout() async {
    await authRepository.logout();
    Get.snackbar(
      'Logout',
      'You have logged out successfully.',
      snackPosition: SnackPosition.BOTTOM,
    );
    Get.offAll(() => const LoginScreen());
  }
}

import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';

import '../data/models/employee_model.dart';
import '../data/repositories/employee_repository.dart';

class EmployeeController extends GetxController {
  final EmployeeRepository repository;

  EmployeeController({EmployeeRepository? repository})
    : repository = repository ?? EmployeeRepository();

  // Employee list
  final RxList<Employee> employees = <Employee>[].obs;

  // Loading state
  final RxBool isLoading = false.obs;

  // Error message
  final RxString errorMessage = ''.obs;

  // Fetch employees
  Future<void> fetchEmployees() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final result = await repository.getEmployees();

      employees.assignAll(result);
    } on DioException catch (e) {
      errorMessage.value =
          e.response?.data?['message']?.toString() ??
          e.message ??
          'Failed to load employees';
    } catch (e) {
      errorMessage.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }

  // Add employee
  Future<bool> addEmployee(Employee employee) async {
    try {
      isLoading.value = true;

      final newEmployee = await repository.addEmployee(employee);

      employees.insert(0, newEmployee);

      Get.snackbar(
        'Success',
        'Employee added successfully',
        snackPosition: SnackPosition.BOTTOM,
      );

      return true;
    } on DioException catch (e) {
      _showError(e.message ?? 'Failed to add employee');
      return false;
    } catch (e) {
      _showError(e.toString());
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  // Update employee
  Future<bool> updateEmployee(Employee employee) async {
    try {
      isLoading.value = true;

      final updatedEmployee = await repository.updateEmployee(employee);

      final index = employees.indexWhere((item) => item.id == employee.id);

      if (index != -1) {
        employees[index] = updatedEmployee;
      }

      Get.snackbar(
        'Success',
        'Employee updated successfully',
        snackPosition: SnackPosition.BOTTOM,
      );

      return true;
    } on DioException catch (e) {
      _showError(e.message ?? 'Failed to update employee');
      return false;
    } catch (e) {
      _showError(e.toString());
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  // Delete employee
  Future<bool> deleteEmployee(int id) async {
    try {
      isLoading.value = true;

      await repository.deleteEmployee(id);

      employees.removeWhere((employee) => employee.id == id);

      Get.snackbar(
        'Success',
        'Employee deleted successfully',
        snackPosition: SnackPosition.BOTTOM,
      );

      return true;
    } on DioException catch (e) {
      _showError(e.message ?? 'Failed to delete employee');
      return false;
    } catch (e) {
      _showError(e.toString());
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  // Refresh employee list
  Future<void> refreshEmployees() async {
    await fetchEmployees();
  }

  // Show error message
  void _showError(String message) {
    Get.snackbar(
      'Error',
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: const Color(0xFFFFEBEE),
      colorText: const Color(0xFFB71C1C),
    );
  }

  @override
  void onInit() {
    super.onInit();
    fetchEmployees();
  }
}

class ApiConstants {
  // DummyJSON Login
  static const String baseUrl = 'https://dummyjson.com';

  static const String login = '/auth/login';

  // Render Online API
  static const String localApiBaseUrl =
      'https://employee-management-app-d8tt.onrender.com';

  // API Endpoints
  static const String products = '/products';
  static const String employees = '/employees';

  static const String employeeBaseUrl = localApiBaseUrl;
}
